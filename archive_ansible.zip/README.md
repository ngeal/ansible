# ansible
Ce repository contient les différents scripts .yml exécutable par Ansible
